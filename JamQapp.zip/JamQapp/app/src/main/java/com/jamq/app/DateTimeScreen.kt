package com.jamq.app
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import java.util.Calendar
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.jamq.app.components.JudulBlok
import com.jamq.app.components.TombolKembali

@Composable
fun DateTimeScreen(navController: NavHostController) {
    val context = LocalContext.current
    val calendar = remember { Calendar.getInstance() }

    var selectedDate by remember { mutableStateOf("") }
    var selectedTime by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        JudulBlok("Pengaturan Jam & Tanggal")
        // Label tanggal & jam
        Text("Tanggal : $selectedDate")
        Text("Waktu : $selectedTime")

        // Tombol tanggal & jam dalam 1 baris
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                modifier = Modifier.weight(1f),
                onClick = {
                    DatePickerDialog(
                        context,
                        { _, year, month, day ->
                            selectedDate = "%04d-%02d-%02d".format(year, month + 1, day)
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }
            ) {
                Text("Atur Tanggal")
            }

            Button(
                modifier = Modifier.weight(1f),
                onClick = {
                    TimePickerDialog(
                        context,
                        { _, hour, minute ->
                            selectedTime = "%02d:%02d".format(hour, minute)
                        },
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE),
                        true
                    ).show()
                }
            ) {
                Text("Atur Jam")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (selectedDate.isNotEmpty() && selectedTime.isNotEmpty()) {
                    sendDateTimeToESP(selectedDate, selectedTime)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Kirim ke ESP32")
        }

        TombolKembali(navController)
    }
}


