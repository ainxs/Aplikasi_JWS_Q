package com.jamq.app
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.jamq.app.components.TombolKembali
import androidx.compose.foundation.text.KeyboardOptions
import com.jamq.app.ApiHelper.sendIqomahToESP
import com.jamq.app.components.JudulBlok

@Composable
fun IqomahScreen(navController: NavHostController) {
    val context = LocalContext.current

    var lamaAdzan by remember { mutableStateOf("1") }
    var iqSubuh by remember { mutableStateOf("1") }
    var iqDzuhur by remember { mutableStateOf("1") }
    var iqAshar by remember { mutableStateOf("1") }
    var iqMaghrib by remember { mutableStateOf("1") }
    var iqIsya by remember { mutableStateOf("1") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        JudulBlok("Iqomah dan Adzan")
        OutlinedTextField(
            value = lamaAdzan,
            onValueChange = { lamaAdzan = it },
            label = { Text("Lama Adzan (menit)") },
            keyboardOptions = KeyboardOptions.Default,
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = iqSubuh,
                onValueChange = { iqSubuh = it },
                label = { Text("Iqomah Subuh") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = iqDzuhur,
                onValueChange = { iqDzuhur = it },
                label = { Text("Iqomah Dzuhur") },
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = iqAshar,
                onValueChange = { iqAshar = it },
                label = { Text("Iqomah Ashar") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = iqMaghrib,
                onValueChange = { iqMaghrib = it },
                label = { Text("Iqomah Maghrib") },
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = iqIsya,
            onValueChange = { iqIsya = it },
            label = { Text("Iqomah Isya") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                sendIqomahToESP(
                    lamaAdzan.toIntOrNull() ?: 1,
                    iqSubuh.toIntOrNull() ?: 1,
                    iqDzuhur.toIntOrNull() ?: 1,
                    iqAshar.toIntOrNull() ?: 1,
                    iqMaghrib.toIntOrNull() ?: 1,
                    iqIsya.toIntOrNull() ?: 1
                )
                Toast.makeText(context, "Data Iqomah dikirim ke ESP", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Kirim ke ESP32")
        }

        TombolKembali(navController)
    }
}
