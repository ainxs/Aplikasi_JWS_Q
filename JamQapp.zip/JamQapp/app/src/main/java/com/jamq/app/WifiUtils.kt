package com.jamq.app.utils

import android.widget.Toast
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.provider.Settings
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.jamq.app.R
import kotlinx.coroutines.delay

@Composable
fun WifiConnectIcon() {
    val context = LocalContext.current
    var isConnectedToESP by remember { mutableStateOf(false) }
    var previousStatus by remember { mutableStateOf<Boolean?>(null) }

    // Auto-refresh status koneksi setiap 5 detik
    LaunchedEffect(Unit) {
        while (true) {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val wifiInfo = wifiManager.connectionInfo
            val ssid = wifiInfo.ssid?.removePrefix("\"")?.removeSuffix("\"") ?: ""
            val nowConnected = ssid.contains("ESP32", ignoreCase = true)

            // Hanya kirim toast kalau status berubah
            if (previousStatus != null && previousStatus != nowConnected) {
                if (nowConnected) {
                    Toast.makeText(context, "✅ Terhubung ke ESP32", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "❌ Belum terhubung ke ESP32", Toast.LENGTH_SHORT).show()
                }
            }

            isConnectedToESP = nowConnected
            previousStatus = nowConnected

            delay(5000)
        }
    }

    val iconRes = if (isConnectedToESP) R.drawable.ic_wifiblue else R.drawable.ic_wifired

    Image(
        painter = painterResource(id = iconRes),
        contentDescription = "WiFi Status",
        modifier = Modifier
            .size(70.dp)
            .padding(8.dp)
            .clickable {
                if (!isConnectedToESP) {
                    context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                }
            }
    )
}

