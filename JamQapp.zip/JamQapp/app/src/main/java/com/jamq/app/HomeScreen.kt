package com.jamq.app
import com.jamq.app.utils.WifiConnectIcon
import androidx.navigation.NavHostController
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jamq.app.components.RealTimeClockWithWifi

data class MenuItem(val iconRes: Int, val title: String, val route: String)

@Composable
fun HomeScreen(navController: NavHostController) {
    Box(modifier = Modifier.fillMaxSize()) {

        // 🔲 Atas: Baris jam + WiFi
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, start = 3.dp, end = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Spacer kiri biar jam di tengah (balance)
            Spacer(modifier = Modifier.weight(1f))

            // ⏰ JAM DI TENGAH
            RealTimeClockWithWifi()
            // Spacer kanan biar sejajar
            Spacer(modifier = Modifier.weight(1f))
            // 📶 Icon WiFi di kanan
            WifiConnectIcon()
        }

        // 🟦 2. Konten Grid Menu mulai setelah tinggi icon WiFi
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 120.dp) // kasih jarak dari atas biar ga tumpang tindih
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                val menuItems = listOf(
                    MenuItem(R.drawable.ic_jam, "Jam & Tanggal", "datetime"),
                    MenuItem(R.drawable.ic_adzaniqomah, "Adzan Iqomah", "iqomah"),
                    MenuItem(R.drawable.ic_info, "Informasi", "info"),
                    MenuItem(R.drawable.ic_koreksi, "Koreksi", "koreksi"),
                    MenuItem(R.drawable.ic_lokasi, "Lokasi", "lokasi"),
                    MenuItem(R.drawable.ic_tampilan, "Tampilan", "tampilan"),
                    MenuItem(R.drawable.ic_warna, "Warna", "warna"),
                    MenuItem(R.drawable.ic_pengaturan, "Pengaturan", "pengaturan"),
                    MenuItem(R.drawable.ic_tartil, "Tartil", "tartil")
                )

                items(menuItems) { item ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                navController.navigate(item.route)
                            },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = item.iconRes),
                            contentDescription = item.title,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = item.title, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}


