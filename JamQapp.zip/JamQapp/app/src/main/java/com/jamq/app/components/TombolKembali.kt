package com.jamq.app.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavHostController

@Composable
fun TombolKembali(navController: NavHostController) {
    Button(
        onClick = { navController.popBackStack() },
        modifier = Modifier.fillMaxWidth()

    ) {
        Text("Kembali")
    }
}
